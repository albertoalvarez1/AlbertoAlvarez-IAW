<?php
require_once 'check_auth.php';
include 'cabecera.php';
include ("config.php");

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Filtrado opcional por origen
$filter_origin = $_GET['origin'] ?? '';

// Construir consulta
if ($filter_origin !== '') {
    $sql = "SELECT id, flight_code, origin, destination, departure, arrival, passengers 
            FROM flights 
            WHERE origin = '" . mysqli_real_escape_string($conn, $filter_origin) . "' 
            ORDER BY flight_code";
} else {
    $sql = "SELECT id, flight_code, origin, destination, departure, arrival, passengers 
            FROM flights 
            ORDER BY flight_code";
}

$result = mysqli_query($conn, $sql);
?>

<div class="row">
    <div class="col-12">
        <div class="card mt-4 shadow">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0"><i class="bi bi-filter"></i> Filtrar y Ordenar Vuelos</h5>
            </div>
            <div class="card-body">

                <!-- Formulario de filtrado -->
                <form class="row g-3 mb-3" method="get">
                    <div class="col-md-4">
                        <input type="text" name="origin" class="form-control" placeholder="Filtrar por origen" value="<?php echo htmlspecialchars($filter_origin); ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i> Filtrar</button>
                        <a href="data_select_where_orderby_html_table.php" class="btn btn-secondary"><i class="bi bi-x-circle"></i> Limpiar</a>
                    </div>
                </form>

                <?php if ($result === false): ?>
                    <div class="alert alert-danger">
                        Error: <?php echo $sql; ?><br><?php echo mysqli_error($conn); ?>
                    </div>
                <?php elseif (mysqli_num_rows($result) > 0): ?>
                    <?php $rows = mysqli_fetch_all($result, MYSQLI_ASSOC); ?>

                    <div class="table-responsive">
                        <table class="table table-striped table-hover table-bordered">
                            <thead class="table-primary">
                                <tr>
                                    <th>ID</th>
                                    <th>Código Vuelo</th>
                                    <th>Origen</th>
                                    <th>Destino</th>
                                    <th>Salida</th>
                                    <th>Llegada</th>
                                    <th>Pasajeros</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rows as $row): ?>
                                <tr>
                                    <td><?php echo $row["id"]; ?></td>
                                    <td><?php echo htmlspecialchars($row["flight_code"]); ?></td>
                                    <td><?php echo htmlspecialchars($row["origin"]); ?></td>
                                    <td><?php echo htmlspecialchars($row["destination"]); ?></td>
                                    <td><?php echo $row["departure"]; ?></td>
                                    <td><?php echo $row["arrival"]; ?></td>
                                    <td><?php echo $row["passengers"]; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                <?php else: ?>
                    <div class="alert alert-warning text-center">
                        No se encontraron vuelos
                    </div>
                <?php endif; ?>

                <a href="index.php" class="btn btn-primary mt-3">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

<?php
require_once 'check_auth.php';
require_once 'helpers.php';
include 'cabecera.php';

include ("config.php");

$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card mt-4">
            <div class="card-header bg-danger text-white">
                <h5 class="card-title mb-0"><i class="bi bi-trash"></i> Borrar Usuario por ID</h5>
            </div>
            <div class="card-body">
                <form method="post" class="row g-3">
                    <div class="col-12">
                        <label class="form-label">ID del usuario a borrar:</label>
                        <input type="number" name="id" class="form-control" min="1" required>
                        <div class="form-text">Introduce el ID numérico del usuario</div>
                    </div>
                    <div class="col-12">
                        <button type="submit" name="borrar" class="btn btn-danger w-100">
                            <i class="bi bi-trash"></i> Borrar Usuario
                        </button>
                    </div>
                </form>

                <?php
                if (isset($_REQUEST['borrar'])) {
                    $id = recoge('id');
                    
                    if ($id != "") {
                        $sql = "DELETE FROM MyGuests WHERE id = $id";
                        
                        if (mysqli_query($conn, $sql)) {
                            echo '<div class="alert alert-success mt-3">Usuario con ID ' . $id . ' borrado correctamente</div>';
                        } else {
                            echo '<div class="alert alert-danger mt-3">Error: ' . mysqli_error($conn) . '</div>';
                        }
                    } else {
                        echo '<div class="alert alert-warning mt-3">Ingrese un ID válido</div>';
                    }
                }
                ?>
                
                <div class="mt-3">
                    <a href="index.php" class="btn btn-primary">
                        <i class="bi bi-arrow-left"></i> Volver al menú
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>
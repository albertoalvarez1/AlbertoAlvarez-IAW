<?php
session_start();
// Verificar si está logueado
if ($_SESSION['login'] != "si") {
    header('Location: login.php');
    exit;
}
?>
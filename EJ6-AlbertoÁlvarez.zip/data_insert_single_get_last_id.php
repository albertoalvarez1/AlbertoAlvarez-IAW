<?php
require_once 'check_auth.php';
include 'cabecera.php';
include 'config.php';

// Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die('<div class="alert alert-danger"><i class="bi bi-x-circle"></i> Conexión fallida: ' . mysqli_connect_error() . '</div>');
}

// Insertar un vuelo y obtener el último ID
$sql = "INSERT INTO flights (flight_code, origin, destination, departure, arrival, passengers)
VALUES ('AV102', 'CUN', 'MEX', '2025-12-26 08:00:00', '2025-12-26 10:30:00', 120)";

if (mysqli_query($conn, $sql) == false) {
    $mensaje = "Error al insertar el vuelo: " . mysqli_error($conn);
    $tipo = "danger";
} else {
    $last_id = mysqli_insert_id($conn);
    $mensaje = "Vuelo insertado correctamente ✅ <br><strong>Último ID insertado:</strong> " . $last_id;
    $tipo = "success";
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4 shadow">
            <div class="card-header bg-success text-white">
                <h5 class="card-title mb-0"><i class="bi bi-airplane-engines"></i> Insertar Vuelo y Obtener Último ID</h5>
            </div>
            <div class="card-body text-center">
                <div class="alert alert-<?php echo $tipo; ?>">
                    <?php echo $mensaje; ?>
                </div>
                <a href="index.php" class="btn btn-success">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

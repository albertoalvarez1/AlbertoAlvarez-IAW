<?php
require_once 'check_auth.php';
include 'cabecera.php';
include ("config.php");

// Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Contar registros en la tabla flights
$sql = "SELECT COUNT(*) AS total_records FROM flights";
$result = mysqli_query($conn, $sql);

if ($result == false) {
    $mensaje = "Error en la consulta: " . mysqli_error($conn);
    $tipo = "danger";
} else {
    $row = mysqli_fetch_assoc($result);
    $records_count = $row["total_records"];
    $mensaje = "La tabla <strong>flights</strong> contiene <strong>" . $records_count . "</strong> registros.";
    $tipo = "info";
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4 shadow">
            <div class="card-header bg-info text-white">
                <h5 class="card-title mb-0"><i class="bi bi-123"></i> Contar Registros de Vuelos</h5>
            </div>
            <div class="card-body text-center">
                <div class="alert alert-<?php echo $tipo; ?>">
                    <h4><?php echo $mensaje; ?></h4>
                </div>
                <a href="index.php" class="btn btn-primary">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

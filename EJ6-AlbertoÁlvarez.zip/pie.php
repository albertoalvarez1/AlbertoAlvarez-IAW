<?php
?>
    </div>

    <footer class="mt-5 py-4 bg-dark text-light">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
                    <span>
                        <i class="bi bi-airplane-engines text-info"></i>
                        © <?php echo date('Y'); ?> <strong>AeroDestino</strong> · Sistema de Gestión de Vuelos
                    </span>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <span class="text-secondary">
                        Operando con tecnología <i class="bi bi-bootstrap-fill text-info"></i> Bootstrap 5
                    </span>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

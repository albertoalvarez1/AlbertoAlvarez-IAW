<?php
require_once 'check_auth.php';
include 'cabecera.php';
include 'config.php';

// Crear conexión sin seleccionar DB
$conn = mysqli_connect($servername, $username, $password);

// Comprobar conexión
if (!$conn) {
    ?>
    <div class="row">
        <div class="col-md-6 mx-auto">
            <div class="card mt-4 shadow">
                <div class="card-header bg-danger text-white">
                    <h5 class="card-title mb-0">
                        <i class="bi bi-exclamation-triangle"></i> Conexión fallida
                    </h5>
                </div>
                <div class="card-body text-center">
                    <div class="alert alert-danger">
                        <h4><i class="bi bi-x-circle"></i> ¡No se pudo conectar!</h4>
                        <p class="mb-0"><?php echo mysqli_connect_error(); ?></p>
                    </div>
                    <a href="index.php" class="btn btn-danger">
                        <i class="bi bi-arrow-left"></i> Volver al menú
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php
    include 'pie.php';
    exit;
}

// Crear base de datos AeroDestino
$sql = "CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";

if (mysqli_query($conn, $sql)) {
    $mensaje = "Base de datos <strong>$dbname</strong> creada correctamente ✅";
    $tipo = "success";
} else {
    $mensaje = "Error al crear la base de datos: " . mysqli_error($conn);
    $tipo = "danger";
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4 shadow">
            <div class="card-header bg-info text-white">
                <h5 class="card-title mb-0">
                    <i class="bi bi-database-add"></i> Crear Base de Datos AeroDestino
                </h5>
            </div>
            <div class="card-body text-center">
                <?php if(isset($mensaje)): ?>
                    <div class="alert alert-<?php echo $tipo; ?>">
                        <?php echo $mensaje; ?>
                    </div>
                <?php endif; ?>
                <a href="index.php" class="btn btn-info">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

<?php
require_once 'check_auth.php';
include 'cabecera.php';
include 'config.php';

// Conexión sin seleccionar base de datos
$conn = mysqli_connect($servername, $username, $password);

// Comprobar conexión
if (!$conn) {
    die('<div class="alert alert-danger"><i class="bi bi-x-circle"></i> Conexión fallida: ' . mysqli_connect_error() . '</div>');
}

// SQL para borrar la base de datos si existe
$sql = "DROP DATABASE IF EXISTS `$dbname`";

if (mysqli_query($conn, $sql)) {
    $mensaje = "Base de datos <strong>$dbname</strong> borrada correctamente ✅ (si existía)";
    $tipo = "warning";
} else {
    $mensaje = "Error al borrar la base de datos: " . mysqli_error($conn);
    $tipo = "danger";
}
?>
<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4 shadow">
            <div class="card-header bg-danger text-white">
                <h5 class="card-title mb-0"><i class="bi bi-database-dash"></i> Borrar Base de Datos AeroDestino</h5>
            </div>
            <div class="card-body text-center">
                <?php if(isset($mensaje)): ?>
                <div class="alert alert-<?php echo $tipo; ?>">
                    <?php echo $mensaje; ?>
                </div>
                <?php endif; ?>
                <a href="index.php" class="btn btn-danger">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

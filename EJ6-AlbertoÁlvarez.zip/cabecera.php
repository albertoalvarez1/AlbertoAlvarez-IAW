<?php
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AeroDestino | Sistema de Vuelos</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow">
    <div class="container-fluid">

        <a class="navbar-brand fw-bold" href="index.php">
            <i class="bi bi-airplane-engines text-info"></i> AeroDestino
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">

                <!-- Vuelos -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-airplane"></i> Vuelos
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="db_connect.php"><i class="bi bi-plug"></i> Conectar</a></li>
                        <li><a class="dropdown-item" href="db_create.php"><i class="bi bi-database-add"></i> Crear base de datos</a></li>
                        <li><a class="dropdown-item" href="db_drop.php"><i class="bi bi-database-dash"></i> Borrar base de datos</a></li>
                        <li><a class="dropdown-item" href="table_create_flights.php"><i class="bi bi-table"></i> Crear vuelo</a></li>
                        <li><a class="dropdown-item" href="table_drop_flights.php"><i class="bi bi-trash"></i> Borrar vuelo</a></li>
                    </ul>
                </li>

                <!-- Insertar datos -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-node-plus"></i> Insertar datos
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="data_insert_single.php"><i class="bi bi-person-plus"></i> Insertar registro</a></li>
                        <li><a class="dropdown-item" href="data_insert_single_get_last_id.php"><i class="bi bi-person-plus"></i> Insertar y obtener último ID</a></li>
                        <li><a class="dropdown-item" href="data_insert_multiple_simple.php"><i class="bi bi-list-check"></i> Insertar sin preparar</a></li>
                        <li><a class="dropdown-item" href="data_insert_multiple_prepared.php"><i class="bi bi-list-stars"></i> Insertar múltiples registros</a></li>
                        <li><a class="dropdown-item" href="data_count.php"><i class="bi bi-123"></i> Contar registros</a></li>
                        <li><a class="dropdown-item" href="form_insert.php"><i class="bi bi-input-cursor-text"></i>Insertar desde formulario</a></li>
                        <li><a class="dropdown-item" href="load_flights.php"><i class="bi bi-input-cursor-text"></i>Carga Masiva</a></li>
                    </ul>
                </li>

                <!-- Visualizar -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-eye"></i> Visualizar
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="data_select_all.php"><i class="bi bi-list-columns"></i> Todos los datos</a></li>
                        <li><a class="dropdown-item" href="data_select_orderby.php"><i class="bi bi-sort-alpha-down"></i> Datos ordenados</a></li>
                        <li><a class="dropdown-item" href="data_select_where_orderby_html_table.php"><i class="bi bi-filter"></i> Datos filtrados</a></li>
                    </ul>
                </li>

                <!-- Otros -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-gear"></i> Otros
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="data_delete.php"><i class="bi bi-x-circle"></i> Borrar por ID</a></li>
                        <li><a class="dropdown-item" href="data_update.php"><i class="bi bi-pencil-square"></i> Actualizar</a></li>
                        <li><a class="dropdown-item" href="form_search.php"><i class="bi bi-search"></i> Buscar</a></li>
                    </ul>
                </li>

            </ul>

            <!-- Usuario y Logout -->
            <ul class="navbar-nav align-items-center">
                <li class="nav-item me-3 text-white">
                    <i class="bi bi-person-circle"></i>
                    <?php echo htmlspecialchars($_SESSION['usuario'] ?? 'Usuario'); ?>
                </li>
                <li class="nav-item">
                    <a class="btn btn-outline-info btn-sm" href="logout.php">
                        <i class="bi bi-box-arrow-right"></i> Salir
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">

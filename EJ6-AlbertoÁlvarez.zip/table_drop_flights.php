<?php
require_once 'check_auth.php';
include 'cabecera.php';
include 'config.php';

// Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Deshabilitar temporalmente las foreign keys
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS=0");

// Borrar tabla flights
$sql_flights = "DROP TABLE IF EXISTS flights";
if (mysqli_query($conn, $sql_flights) == false) {
    $mensaje_flights = "Error al borrar la tabla <strong>flights</strong>: " . mysqli_error($conn);
    $tipo_flights = "danger";
} else {
    $mensaje_flights = "Tabla <strong>flights</strong> eliminada correctamente ✅";
    $tipo_flights = "warning";
}

// Volver a habilitar foreign keys
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS=1");
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4 shadow">
            <div class="card-header bg-danger text-white">
                <h5 class="card-title mb-0"><i class="bi bi-trash"></i> Borrar Tabla Flights</h5>
            </div>
            <div class="card-body text-center">
                <div class="alert alert-<?php echo $tipo_flights; ?>">
                    <?php echo $mensaje_flights; ?>
                </div>
                <a href="index.php" class="btn btn-danger">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

<?php
require_once 'check_auth.php';
require_once 'helpers.php';
include 'cabecera.php';
include("config.php");

// Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die('<div class="alert alert-danger">Error de conexión: ' . mysqli_connect_error() . '</div>');
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4">
            <div class="card-header bg-info text-white">
                <h5 class="card-title mb-0"><i class="bi bi-search"></i> Buscar Vuelo por Código</h5>
            </div>
            <div class="card-body">
                <form method="post" class="row g-3 mb-4">
                    <div class="col-md-8">
                        <label class="form-label">Código de vuelo:</label>
                        <input type="text" name="flight_code" class="form-control" placeholder="Ej: AV101" required>
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="submit" name="buscar" class="btn btn-info w-100">
                            <i class="bi bi-search"></i> Buscar
                        </button>
                    </div>
                </form>

                <?php
                if (isset($_POST['buscar'])) {
                    $flight_code = mysqli_real_escape_string($conn, recoge('flight_code'));

                    $sql = "SELECT id, flight_code, origin, destination, departure, arrival, passengers 
                            FROM flights 
                            WHERE flight_code LIKE '%$flight_code%'";
                    $result = mysqli_query($conn, $sql);

                    if ($result === false) {
                        echo '<div class="alert alert-danger">Error en la consulta: ' . mysqli_error($conn) . '</div>';
                    } elseif (mysqli_num_rows($result) > 0) {
                        echo '<div class="table-responsive"><table class="table table-striped table-hover">';
                        echo '<thead class="table-info">
                                <tr>
                                    <th>ID</th>
                                    <th>Código</th>
                                    <th>Origen</th>
                                    <th>Destino</th>
                                    <th>Salida</th>
                                    <th>Llegada</th>
                                    <th>Pasajeros</th>
                                </tr>
                              </thead><tbody>';
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo '<tr>';
                            echo '<td>'.$row['id'].'</td>';
                            echo '<td>'.$row['flight_code'].'</td>';
                            echo '<td>'.$row['origin'].'</td>';
                            echo '<td>'.$row['destination'].'</td>';
                            echo '<td>'.$row['departure'].'</td>';
                            echo '<td>'.$row['arrival'].'</td>';
                            echo '<td>'.$row['passengers'].'</td>';
                            echo '</tr>';
                        }
                        echo '</tbody></table></div>';
                    } else {
                        echo '<div class="alert alert-warning">No se encontraron vuelos para "'.$flight_code.'"</div>';
                    }
                }
                ?>

                <div class="mt-3">
                    <a href="index.php" class="btn btn-primary">
                        <i class="bi bi-arrow-left"></i> Volver al menú
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

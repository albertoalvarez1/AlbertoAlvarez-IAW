<?php
require_once 'check_auth.php';
include 'cabecera.php';
?>

<div class="row">
    <div class="col-12">
        <div class="alert alert-primary d-flex align-items-center">
            <i class="bi bi-airplane-engines fs-3 me-3"></i>
            <div>
                <h4 class="mb-1">Panel Principal – AeroDestino</h4>
                <p class="mb-0">Bienvenido al sistema interno de gestión de vuelos y operaciones aéreas.</p>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-md-6 col-lg-3">
                <div class="card shadow-sm h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-airplane fs-1 text-primary"></i>
                        <h5 class="mt-3">Vuelos</h5>
                        <p class="text-muted">Gestión de rutas, horarios y estados de vuelo.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="card shadow-sm h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-people fs-1 text-success"></i>
                        <h5 class="mt-3">Pasajeros</h5>
                        <p class="text-muted">Registro y control de clientes y reservas.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="card shadow-sm h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-person-badge fs-1 text-warning"></i>
                        <h5 class="mt-3">Tripulación</h5>
                        <p class="text-muted">Pilotos, copilotos y personal de cabina.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="card shadow-sm h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-bar-chart fs-1 text-danger"></i>
                        <h5 class="mt-3">Reportes</h5>
                        <p class="text-muted">Estadísticas y control operativo.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0"><i class="bi bi-info-circle"></i> Información del Sistema</h5>
            </div>
            <div class="card-body">
                <p>AeroDestino es una plataforma diseñada para administrar vuelos comerciales de forma eficiente y segura.</p>
                <ul>
                    <li><strong>Operaciones:</strong> control de vuelos, aeronaves y horarios</li>
                    <li><strong>Clientes:</strong> gestión de pasajeros y reservas</li>
                    <li><strong>Personal:</strong> administración de tripulación</li>
                    <li><strong>Datos:</strong> integración con base de datos MySQL</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php
include 'pie.php';
?>

<?php
require_once 'check_auth.php';
require_once 'helpers.php';
include 'cabecera.php';

include ("config.php");

$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card mt-4">
            <div class="card-header bg-warning text-dark">
                <h5 class="card-title mb-0"><i class="bi bi-pencil-square"></i> Actualizar Apellido de Usuario</h5>
            </div>
            <div class="card-body">
                <form method="post" class="row g-3">
                    <div class="col-12">
                        <label class="form-label">ID del usuario:</label>
                        <input type="number" name="id" class="form-control" min="1" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Nuevo Apellido:</label>
                        <input type="text" name="new_lastname" class="form-control" required>
                    </div>
                    <div class="col-12">
                        <button type="submit" name="actualizar" class="btn btn-warning w-100">
                            <i class="bi bi-check-circle"></i> Actualizar
                        </button>
                    </div>
                </form>

                <?php
                if (isset($_REQUEST['actualizar'])) {
                    $id = recoge('id');
                    $new_lastname = recoge('new_lastname');
                    
                    if ($id != "" && $new_lastname != "") {
                        $sql = "UPDATE MyGuests SET lastname = '$new_lastname' WHERE id = $id";
                        
                        if (mysqli_query($conn, $sql)) {
                            echo '<div class="alert alert-success mt-3">Usuario con ID ' . $id . ' actualizado correctamente</div>';
                        } else {
                            echo '<div class="alert alert-danger mt-3">Error: ' . mysqli_error($conn) . '</div>';
                        }
                    } else {
                        echo '<div class="alert alert-warning mt-3">Complete todos los campos</div>';
                    }
                }
                ?>
                
                <div class="mt-3">
                    <a href="index.php" class="btn btn-primary">
                        <i class="bi bi-arrow-left"></i> Volver al menú
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>
<?php
require_once 'check_auth.php';
include 'cabecera.php';
include ("config.php");

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$mensaje = "";
$tipo = "";

if (isset($_POST['id'])) {
    $id = intval($_POST['id']); // Convertir a entero por seguridad

    if ($id > 0) {
        $sql = "DELETE FROM flights WHERE id=$id";
        if (!mysqli_query($conn, $sql)) {
            $mensaje = "Error al borrar el vuelo: " . mysqli_error($conn);
            $tipo = "danger";
        } elseif (mysqli_affected_rows($conn) == 0) {
            $mensaje = "No existe ningún vuelo con ID $id.";
            $tipo = "warning";
        } else {
            $mensaje = "Vuelo con ID $id eliminado correctamente ✅";
            $tipo = "success";
        }
    } else {
        $mensaje = "ID inválido.";
        $tipo = "warning";
    }
}
?>

<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card mt-4 shadow">
            <div class="card-header bg-danger text-white">
                <h5 class="card-title mb-0"><i class="bi bi-x-circle"></i> Borrar Vuelo por ID</h5>
            </div>
            <div class="card-body text-center">

                <?php if ($mensaje != ""): ?>
                    <div class="alert alert-<?php echo $tipo; ?>">
                        <?php echo $mensaje; ?>
                    </div>
                <?php endif; ?>

                <form method="post" class="d-flex flex-column align-items-center gap-3">
                    <input type="number" name="id" class="form-control w-50" placeholder="Escribe el ID del vuelo" required>
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-trash"></i> Borrar Vuelo
                    </button>
                </form>

                <a href="index.php" class="btn btn-outline-secondary mt-3">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

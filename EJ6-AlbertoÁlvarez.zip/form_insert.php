<?php
require_once 'check_auth.php';
include 'cabecera.php';
require_once 'helpers.php';
include ("config.php");

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (isset($_POST['enviar'])) {
    $flight_code = recoge('flight_code');
    $origin = recoge('origin');
    $destination = recoge('destination');
    $departure = recoge('departure');
    $arrival = recoge('arrival');
    $passengers = recoge('passengers');

    if ($flight_code != "" && $origin != "" && $destination != "" && $departure != "" && $arrival != "") {
        $sql = "INSERT INTO flights (flight_code, origin, destination, departure, arrival, passengers) 
                VALUES ('$flight_code', '$origin', '$destination', '$departure', '$arrival', '$passengers')";

        if (mysqli_query($conn, $sql)) {
            $mensaje = "<div class='alert alert-success'>Vuelo insertado correctamente ✅</div>";
        } else {
            $mensaje = "<div class='alert alert-danger'>Error al insertar: " . mysqli_error($conn) . "</div>";
        }
    } else {
        $mensaje = "<div class='alert alert-warning'>Todos los campos son obligatorios</div>";
    }
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4 shadow">
            <div class="card-header bg-success text-white">
                <h5 class="card-title mb-0">
                    <i class="bi bi-airplane"></i> Insertar Nuevo Vuelo
                </h5>
            </div>
            <div class="card-body">
                <?php if (isset($mensaje)) echo $mensaje; ?>
                
                <form method="post" class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Código de Vuelo</label>
                        <input type="text" name="flight_code" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Origen</label>
                        <input type="text" name="origin" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Destino</label>
                        <input type="text" name="destination" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Salida</label>
                        <input type="datetime-local" name="departure" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Llegada</label>
                        <input type="datetime-local" name="arrival" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Pasajeros</label>
                        <input type="number" name="passengers" class="form-control" value="0" min="0">
                    </div>
                    <div class="col-12">
                        <button type="submit" name="enviar" class="btn btn-success">
                            <i class="bi bi-check-circle"></i> Insertar Vuelo
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Volver al menú
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

<?php
require_once 'check_auth.php';
include 'cabecera.php';
include 'config.php';

// Conexión a la base de datos AeroDestino
$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    ?>
    <div class="row">
        <div class="col-md-6 mx-auto">
            <div class="card mt-4 shadow">
                <div class="card-header bg-danger text-white">
                    <h5 class="card-title mb-0">
                        <i class="bi bi-exclamation-triangle"></i> Error de Conexión
                    </h5>
                </div>
                <div class="card-body text-center">
                    <div class="alert alert-danger">
                        <h4><i class="bi bi-x-circle"></i> ¡No se pudo conectar!</h4>
                        <p class="mb-0"><?php echo mysqli_connect_error(); ?></p>
                    </div>
                    <a href="index.php" class="btn btn-danger">
                        <i class="bi bi-arrow-left"></i> Volver al menú
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php
    include 'pie.php';
    exit;
}
?>

<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card mt-4 shadow">
            <div class="card-header bg-info text-white">
                <h5 class="card-title mb-0">
                    <i class="bi bi-plug"></i> Conexión a la Base de Datos AeroDestino
                </h5>
            </div>
            <div class="card-body text-center">
                <div class="alert alert-success">
                    <h4><i class="bi bi-check-circle"></i> ¡Conectado correctamente!</h4>
                    <p class="mb-0">
                        La conexión a la base de datos <strong><?php echo htmlspecialchars($dbname); ?></strong> se ha establecido con éxito.
                    </p>
                </div>
                <a href="index.php" class="btn btn-info">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php include 'pie.php'; ?>

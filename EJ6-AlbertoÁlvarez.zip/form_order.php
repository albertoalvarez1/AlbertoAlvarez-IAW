<?php
require_once 'check_auth.php';
require_once 'helpers.php';
include 'cabecera.php';

include ("config.php");

$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4">
            <div class="card-header bg-info text-white">
                <h5 class="card-title mb-0"><i class="bi bi-arrow-down-up"></i> Ordenar Datos</h5>
            </div>
            <div class="card-body">
                <form method="post" class="row g-3 mb-4">
                    <div class="col-md-8">
                        <label class="form-label">Orden de visualización:</label>
                        <select name="orden" class="form-select" required>
                            <option value="">Seleccione un orden</option>
                            <option value="ASC">Ascendente (A-Z)</option>
                            <option value="DESC">Descendente (Z-A)</option>
                        </select>
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="submit" name="ordenar" class="btn btn-info w-100">
                            <i class="bi bi-sort-alpha-down"></i> Ordenar
                        </button>
                    </div>
                </form>

                <?php
                if (isset($_REQUEST['ordenar'])) {
                    $orden = recoge('orden');
                    
                    if ($orden == "ASC" || $orden == "DESC") {
                        $sql = "SELECT * FROM MyGuests ORDER BY lastname $orden";
                        $result = mysqli_query($conn, $sql);
                        
                        if (mysqli_num_rows($result) > 0): ?>
                            <h5>Resultados ordenados <?php echo $orden == 'ASC' ? 'ascendentemente' : 'descendentemente'; ?></h5>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead class="table-info">
                                        <tr>
                                            <th>ID</th>
                                            <th>Nombre</th>
                                            <th>Apellido</th>
                                            <th>Email</th>
                                            <th>Teléfono</th>
                                            <th>Código</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                                        <tr>
                                            <td><?php echo $row["id"]; ?></td>
                                            <td><?php echo $row["firstname"]; ?></td>
                                            <td><?php echo $row["lastname"]; ?></td>
                                            <td><?php echo $row["email"]; ?></td>
                                            <td><?php echo $row["phone"]; ?></td>
                                            <td><?php echo $row["cod_user"]; ?></td>
                                        </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                No hay datos para mostrar
                            </div>
                        <?php endif;
                    } else {
                        echo '<div class="alert alert-warning">Seleccione un orden válido</div>';
                    }
                }
                ?>
                
                <div class="mt-3">
                    <a href="index.php" class="btn btn-primary">
                        <i class="bi bi-arrow-left"></i> Volver al menú
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>
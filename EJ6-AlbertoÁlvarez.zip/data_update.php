<?php
require_once 'check_auth.php';
include 'cabecera.php';
include 'config.php';

// Conexión a la base de datos
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die('<div class="alert alert-danger"><i class="bi bi-x-circle"></i> Conexión fallida: ' . mysqli_connect_error() . '</div>');
}

$mensaje = "";
$tipo = "";

// Procesar el formulario
if (isset($_POST['enviar'])) {
    $id = (int) $_POST['id'];
    $flight_code = $_POST['flight_code'];
    $origin = $_POST['origin'];
    $destination = $_POST['destination'];
    $departure = $_POST['departure'];
    $arrival = $_POST['arrival'];
    $passengers = (int) $_POST['passengers'];

    if ($id > 0 && $flight_code != "" && $origin != "" && $destination != "" && $departure != "" && $arrival != "") {
        $sql = "UPDATE flights 
                SET flight_code='$flight_code', origin='$origin', destination='$destination', departure='$departure', arrival='$arrival', passengers='$passengers'
                WHERE id=$id";

        if (!mysqli_query($conn, $sql)) {
            $mensaje = "Error al actualizar el vuelo: " . mysqli_error($conn);
            $tipo = "danger";
        } elseif (mysqli_affected_rows($conn) == 0) {
            $mensaje = "No se encontró el vuelo con ID $id. Nada se actualizó.";
            $tipo = "warning";
        } else {
            $mensaje = "Vuelo con ID <strong>$id</strong> actualizado correctamente ✅";
            $tipo = "success";
        }
    } else {
        $mensaje = "Todos los campos son obligatorios y el ID debe ser mayor que 0.";
        $tipo = "warning";
    }
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4 shadow">
            <div class="card-header bg-warning text-dark">
                <h5 class="card-title mb-0"><i class="bi bi-pencil-square"></i> Actualizar Vuelo</h5>
            </div>
            <div class="card-body">
                <?php if ($mensaje != ""): ?>
                    <div class="alert alert-<?php echo $tipo; ?>"><?php echo $mensaje; ?></div>
                <?php endif; ?>

                <form method="post" class="row g-3">
                    <div class="col-md-2">
                        <label class="form-label">ID Vuelo</label>
                        <input type="number" name="id" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Código Vuelo</label>
                        <input type="text" name="flight_code" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Origen</label>
                        <input type="text" name="origin" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Destino</label>
                        <input type="text" name="destination" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Salida</label>
                        <input type="datetime-local" name="departure" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Llegada</label>
                        <input type="datetime-local" name="arrival" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Pasajeros</label>
                        <input type="number" name="passengers" class="form-control" value="0" min="0" required>
                    </div>
                    <div class="col-12">
                        <button type="submit" name="enviar" class="btn btn-warning">
                            <i class="bi bi-check-circle"></i> Actualizar Vuelo
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Volver al menú
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

<?php
require_once 'check_auth.php';
include 'cabecera.php';
include ("config.php");

// Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Preparar statement para insertar vuelos
$stmt = mysqli_prepare($conn, "INSERT INTO flights (flight_code, origin, destination, departure, arrival, passengers) VALUES (?, ?, ?, ?, ?, ?)");
mysqli_stmt_bind_param($stmt, "sssssi", $flight_code, $origin, $destination, $departure, $arrival, $passengers);

// Primer vuelo
$flight_code = "AV101";
$origin = "CDMX";
$destination = "MTY";
$departure = "2025-12-18 10:00:00";
$arrival = "2025-12-18 12:00:00";
$passengers = 150;
mysqli_stmt_execute($stmt);

// Segundo vuelo
$flight_code = "AV102";
$origin = "MTY";
$destination = "CUN";
$departure = "2025-12-19 09:00:00";
$arrival = "2025-12-19 12:30:00";
$passengers = 180;
mysqli_stmt_execute($stmt);

// Tercer vuelo
$flight_code = "AV103";
$origin = "CUN";
$destination = "CDMX";
$departure = "2025-12-20 15:00:00";
$arrival = "2025-12-20 18:00:00";
$passengers = 160;
mysqli_stmt_execute($stmt);

$mensaje = "Vuelos insertados correctamente ✅";
$tipo = "success";

// Cerrar statement
mysqli_stmt_close($stmt);
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4">
            <div class="card-header bg-success text-white">
                <h5 class="card-title mb-0"><i class="bi bi-list-stars"></i> Insertar Múltiples Vuelos (Preparado)</h5>
            </div>
            <div class="card-body">
                <div class="alert alert-<?php echo $tipo; ?>">
                    <?php echo $mensaje; ?>
                </div>
                <a href="index.php" class="btn btn-primary">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

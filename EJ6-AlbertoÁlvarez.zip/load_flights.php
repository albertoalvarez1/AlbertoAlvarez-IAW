<?php
require_once 'check_auth.php';
include 'cabecera.php';
include 'config.php';

// Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Carga masiva de vuelos
$sql = "
INSERT INTO flights
(flight_code, origin, destination, departure, arrival, passengers)
VALUES
('AV101', 'Madrid', 'Barcelona', '2025-06-01 08:00:00', '2025-06-01 09:15:00', 120),
('AV102', 'Barcelona', 'Paris', '2025-06-01 10:30:00', '2025-06-01 12:20:00', 95),
('AV103', 'Paris', 'Roma', '2025-06-01 14:00:00', '2025-06-01 15:50:00', 110),
('AV104', 'Roma', 'Berlin', '2025-06-02 07:45:00', '2025-06-02 09:55:00', 130),
('AV105', 'Berlin', 'Amsterdam', '2025-06-02 11:30:00', '2025-06-02 13:00:00', 85),
('AV106', 'Amsterdam', 'Lisboa', '2025-06-02 15:20:00', '2025-06-02 18:00:00', 140),
('AV107', 'Lisboa', 'Madrid', '2025-06-03 09:00:00', '2025-06-03 10:20:00', 100),
('AV108', 'Madrid', 'Valencia', '2025-06-03 11:00:00', '2025-06-03 12:00:00', 90),
('AV109', 'Valencia', 'Sevilla', '2025-06-03 13:30:00', '2025-06-03 14:45:00', 75),
('AV110', 'Sevilla', 'Bilbao', '2025-06-04 08:15:00', '2025-06-04 09:45:00', 80),

('AV111', 'Bilbao', 'Paris', '2025-06-04 11:00:00', '2025-06-04 12:40:00', 105),
('AV112', 'Paris', 'Londres', '2025-06-04 14:00:00', '2025-06-04 15:10:00', 150),
('AV113', 'Londres', 'Dublin', '2025-06-05 08:30:00', '2025-06-05 09:45:00', 70),
('AV114', 'Dublin', 'Edinburgh', '2025-06-05 11:00:00', '2025-06-05 12:15:00', 65),
('AV115', 'Edinburgh', 'Oslo', '2025-06-05 14:20:00', '2025-06-05 17:30:00', 95),
('AV116', 'Oslo', 'Stockholm', '2025-06-06 09:10:00', '2025-06-06 10:20:00', 88),
('AV117', 'Stockholm', 'Helsinki', '2025-06-06 11:45:00', '2025-06-06 12:50:00', 92),
('AV118', 'Helsinki', 'Copenhague', '2025-06-06 14:30:00', '2025-06-06 16:10:00', 77),
('AV119', 'Copenhague', 'Praga', '2025-06-07 08:40:00', '2025-06-07 10:55:00', 115),
('AV120', 'Praga', 'Viena', '2025-06-07 12:20:00', '2025-06-07 13:30:00', 83),

('AV121', 'Viena', 'Budapest', '2025-06-07 15:00:00', '2025-06-07 16:05:00', 90),
('AV122', 'Budapest', 'Atenas', '2025-06-08 08:00:00', '2025-06-08 11:10:00', 125),
('AV123', 'Atenas', 'Estambul', '2025-06-08 12:30:00', '2025-06-08 13:50:00', 140),
('AV124', 'Estambul', 'Bucarest', '2025-06-08 15:10:00', '2025-06-08 16:40:00', 98),
('AV125', 'Bucarest', 'Sofia', '2025-06-09 09:30:00', '2025-06-09 10:20:00', 60),
('AV126', 'Sofia', 'Zagreb', '2025-06-09 11:45:00', '2025-06-09 13:00:00', 72),
('AV127', 'Zagreb', 'Venecia', '2025-06-09 14:30:00', '2025-06-09 15:40:00', 85),
('AV128', 'Venecia', 'Milán', '2025-06-10 08:10:00', '2025-06-10 09:00:00', 110),
('AV129', 'Milán', 'Zurich', '2025-06-10 10:30:00', '2025-06-10 11:40:00', 100),
('AV130', 'Zurich', 'Munich', '2025-06-10 13:00:00', '2025-06-10 14:10:00', 95)
";

if (mysqli_query($conn, $sql)) {
    $mensaje = "✅ Carga masiva de vuelos realizada correctamente";
    $tipo = "success";
} else {
    $mensaje = "❌ Error al insertar vuelos: " . mysqli_error($conn);
    $tipo = "danger";
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4 shadow">
            <div class="card-header bg-success text-white">
                <h5 class="card-title mb-0">
                    <i class="bi bi-airplane"></i> Carga Masiva de Vuelos
                </h5>
            </div>
            <div class="card-body text-center">
                <div class="alert alert-<?php echo $tipo; ?>">
                    <?php echo $mensaje; ?>
                </div>
                <a href="index.php" class="btn btn-success">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

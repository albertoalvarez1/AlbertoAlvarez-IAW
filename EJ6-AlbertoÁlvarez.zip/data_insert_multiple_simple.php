<?php
require_once 'check_auth.php';
include 'cabecera.php';
include 'config.php';

// Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die('<div class="alert alert-danger"><i class="bi bi-x-circle"></i> Conexión fallida: ' . mysqli_connect_error() . '</div>');
}

// Insertar múltiples vuelos usando mysqli_multi_query
$sql = "INSERT INTO flights (flight_code, origin, destination, departure, arrival, passengers) 
VALUES ('AV201', 'CUN', 'MEX', '2025-12-26 08:00:00', '2025-12-26 10:30:00', 120);";
$sql .= "INSERT INTO flights (flight_code, origin, destination, departure, arrival, passengers) 
VALUES ('AV202', 'MEX', 'CUN', '2025-12-27 09:00:00', '2025-12-27 11:30:00', 150);";
$sql .= "INSERT INTO flights (flight_code, origin, destination, departure, arrival, passengers) 
VALUES ('AV203', 'CUN', 'GDL', '2025-12-28 07:00:00', '2025-12-28 09:45:00', 100);";


if (mysqli_multi_query($conn, $sql)) {
    $mensaje = "Vuelos insertados correctamente ✅";
    $tipo = "success";
} else {
    $mensaje = "Error al insertar vuelos: " . mysqli_error($conn);
    $tipo = "danger";
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4 shadow">
            <div class="card-header bg-success text-white">
                <h5 class="card-title mb-0"><i class="bi bi-list-check"></i> Insertar Múltiples Vuelos (Simple)</h5>
            </div>
            <div class="card-body text-center">
                <div class="alert alert-<?php echo $tipo; ?>">
                    <?php echo $mensaje; ?>
                </div>
                <a href="index.php" class="btn btn-success">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

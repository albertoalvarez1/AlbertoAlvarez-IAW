<?php
require_once 'check_auth.php';
include 'cabecera.php';
include ("config.php");

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "SHOW TABLES LIKE 'MyGuests'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 0) {
    $mensaje = "La tabla <strong>MyGuests</strong> no existe. No se puede visualizar.";
    $tipo = "warning";
} else {
    $mensaje = "La tabla <strong>MyGuests</strong> existe.";
    $tipo = "success";
}
?>
<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4">
            <div class="card-header bg-secondary text-white">
                <h5 class="card-title mb-0"><i class="bi bi-question-circle"></i> Verificar Existencia de Tabla</h5>
            </div>
            <div class="card-body">
                <div class="alert alert-<?php echo $tipo; ?>">
                    <?php echo $mensaje; ?>
                </div>
                <a href="index.php" class="btn btn-primary">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>
<?php
session_start();
if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AeroDestino | Acceso</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            min-height: 100vh;
            background: url('https://images.unsplash.com/photo-1542296332-2e4473faf563') center/cover no-repeat;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .overlay {
            position: absolute;
            inset: 0;
            background: rgba(10, 30, 60, 0.75);
        }
        .login-box {
            position: relative;
            background: #ffffff;
            border-radius: 18px;
            padding: 2.5rem;
            box-shadow: 0 25px 50px rgba(0,0,0,.35);
        }
        .brand {
            color: #0d6efd;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .brand i {
            color: #0dcaf0;
        }
    </style>
</head>
<body>

<div class="overlay"></div>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-4">
            <div class="login-box">
                <div class="text-center mb-4">
                    <h2 class="brand"><i class="bi bi-airplane-engines"></i> AeroDestino</h2>
                    <p class="text-muted mb-0">Gestión de vuelos y reservas</p>
                </div>

                <?php
                if (!empty($_POST['usuario']) && !empty($_POST['clave'])) {
                    $usuario = $_POST['usuario'];
                    $clave   = $_POST['clave'];

                    if ($usuario === 'admin' && $clave === 'P4ssw0rd') {
                        $_SESSION['login'] = true;
                        $_SESSION['usuario'] = $usuario;
                        header('Location: index.php');
                        exit;
                    } else {
                        echo '<div class="alert alert-danger text-center">Credenciales inválidas</div>';
                    }
                }
                ?>

                <form method="post">
                    <div class="mb-3">
                        <label class="form-label">Usuario</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-person-badge"></i></span>
                            <input type="text" name="usuario" class="form-control" placeholder="admin" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Contraseña</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-shield-lock"></i></span>
                            <input type="password" name="clave" class="form-control" placeholder="********" required>
                        </div>
                    </div>

                    <button class="btn btn-primary w-100 py-2">
                        <i class="bi bi-box-arrow-in-right"></i> Ingresar
                    </button>
                </form>

                <div class="text-center mt-4">
                    <small class="text-muted">Acceso interno AeroDestino ✈️</small>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

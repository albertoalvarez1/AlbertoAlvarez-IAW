<?php
require_once 'check_auth.php';
include 'cabecera.php';
include 'config.php';

// Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die('<div class="alert alert-danger"><i class="bi bi-x-circle"></i> Conexión fallida: ' . mysqli_connect_error() . '</div>');
}

// Insertar un registro de vuelo
$sql = "INSERT INTO flights (flight_code, origin, destination, departure, arrival, passengers)
VALUES ('AV101', 'CUN', 'MEX', '2025-12-25 10:00:00', '2025-12-25 12:30:00', 150)";

if (!mysqli_query($conn, $sql)) {
    $mensaje = "Error al insertar el registro: " . mysqli_error($conn);
    $tipo = "danger";
} else {
    $mensaje = "Registro del vuelo <strong>AV101</strong> insertado correctamente ✅";
    $tipo = "success";
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4 shadow">
            <div class="card-header bg-success text-white">
                <h5 class="card-title mb-0"><i class="bi bi-airplane-engines"></i> Insertar Registro Único - Vuelo</h5>
            </div>
            <div class="card-body text-center">
                <div class="alert alert-<?php echo $tipo; ?>">
                    <?php echo $mensaje; ?>
                </div>
                <a href="index.php" class="btn btn-success">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

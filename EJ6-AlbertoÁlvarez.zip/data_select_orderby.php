<?php
require_once 'check_auth.php';
include 'cabecera.php';
include ("config.php");

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Consulta ordenada por código de vuelo
$sql = "SELECT id, flight_code, origin, destination, departure, arrival, passengers, created_at 
        FROM flights 
        ORDER BY flight_code";
$result = mysqli_query($conn, $sql);
?>

<div class="row">
    <div class="col-12">
        <div class="card mt-4 shadow">
            <div class="card-header bg-info text-white">
                <h5 class="card-title mb-0"><i class="bi bi-sort-alpha-down"></i> Vuelos Ordenados por Código</h5>
            </div>
            <div class="card-body">
                <?php if ($result === false): ?>
                    <div class="alert alert-danger">
                        Error: <?php echo $sql; ?><br><?php echo mysqli_error($conn); ?>
                    </div>
                <?php elseif (mysqli_num_rows($result) > 0): ?>
                    <?php $rows = mysqli_fetch_all($result, MYSQLI_ASSOC); ?>
                    
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-info">
                                <tr>
                                    <th>ID</th>
                                    <th>Código Vuelo</th>
                                    <th>Origen</th>
                                    <th>Destino</th>
                                    <th>Salida</th>
                                    <th>Llegada</th>
                                    <th>Pasajeros</th>
                                    <th>Creado en</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rows as $row): ?>
                                <tr>
                                    <td><?php echo $row["id"]; ?></td>
                                    <td><?php echo htmlspecialchars($row["flight_code"]); ?></td>
                                    <td><?php echo htmlspecialchars($row["origin"]); ?></td>
                                    <td><?php echo htmlspecialchars($row["destination"]); ?></td>
                                    <td><?php echo $row["departure"]; ?></td>
                                    <td><?php echo $row["arrival"]; ?></td>
                                    <td><?php echo $row["passengers"]; ?></td>
                                    <td><?php echo $row["created_at"]; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning text-center">
                        No se encontraron registros
                    </div>
                <?php endif; ?>
                
                <a href="index.php" class="btn btn-primary mt-3">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

<?php
require_once 'check_auth.php';
include 'cabecera.php';
include 'config.php';

// Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

/* =========================
   CREAR TABLA FLIGHTS
   ========================= */
$sql_create = "
CREATE TABLE IF NOT EXISTS flights (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    flight_code VARCHAR(10) NOT NULL,
    origin VARCHAR(50) NOT NULL,
    destination VARCHAR(50) NOT NULL,
    departure DATETIME NOT NULL,
    arrival DATETIME NOT NULL,
    passengers INT UNSIGNED DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if (!mysqli_query($conn, $sql_create)) {
    $mensaje = "❌ Error al crear la tabla: " . mysqli_error($conn);
    $tipo = "danger";
} else {
    $sql_insert = "
    INSERT INTO flights (flight_code, origin, destination, departure, arrival, passengers) VALUES
    ('AV101', 'Madrid', 'París', '2025-06-01 08:00:00', '2025-06-01 10:00:00', 120),
    ('AV101', 'Madrid', 'Roma', '2025-06-02 09:30:00', '2025-06-02 11:45:00', 95),
    ('AV202', 'Barcelona', 'Londres', '2025-06-03 07:15:00', '2025-06-03 09:00:00', 140),
    ('AV303', 'Sevilla', 'Berlín', '2025-06-04 13:00:00', '2025-06-04 16:20:00', 110)
    ";

    if (mysqli_query($conn, $sql_insert)) {
        $mensaje = "✅ Tabla <strong>flights</strong> creada e inicializada con vuelos de ejemplo";
        $tipo = "success";
    } else {
        $mensaje = "⚠ Tabla creada, pero error al insertar datos: " . mysqli_error($conn);
        $tipo = "warning";
    }
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card mt-4 shadow">
            <div class="card-header bg-info text-white">
                <h5 class="card-title mb-0">
                    <i class="bi bi-airplane"></i> Crear Tabla de Vuelos
                </h5>
            </div>
            <div class="card-body text-center">
                <div class="alert alert-<?php echo $tipo; ?>">
                    <?php echo $mensaje; ?>
                </div>
                <a href="index.php" class="btn btn-info">
                    <i class="bi bi-arrow-left"></i> Volver al menú
                </a>
            </div>
        </div>
    </div>
</div>

<?php
mysqli_close($conn);
include 'pie.php';
?>

<?php
function recoge($campo) {
    if (isset($_REQUEST[$campo])) {
        return $_REQUEST[$campo];
    }
    return "";
}
?>
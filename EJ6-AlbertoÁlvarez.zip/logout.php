<?php
session_start();
session_unset();
session_destroy();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AeroDestino | Sesión finalizada</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <style>
        body {
            min-height: 100vh;
            background: url('https://images.unsplash.com/photo-1504198453319-5ce911bafcde') center/cover no-repeat;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .overlay {
            position: absolute;
            inset: 0;
            background: rgba(0, 0, 0, 0.7);
        }
        .logout-box {
            position: relative;
            background: #ffffff;
            border-radius: 18px;
            padding: 2.5rem;
            box-shadow: 0 25px 50px rgba(0,0,0,.4);
            text-align: center;
        }
    </style>
</head>
<body>

<div class="overlay"></div>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-4">
            <div class="logout-box">
                <i class="bi bi-airplane-engines fs-1 text-info"></i>
                <h3 class="mt-3">Sesión finalizada</h3>
                <p class="text-muted mt-2">Has salido correctamente del sistema interno de AeroDestino.</p>

                <div class="alert alert-success mt-4">
                    <i class="bi bi-shield-check"></i> Operación realizada de forma segura
                </div>

                <a href="login.php" class="btn btn-info w-100 py-2 mt-3">
                    <i class="bi bi-box-arrow-in-right"></i> Volver a iniciar sesión
                </a>

                <small class="d-block text-muted mt-4">Gracias por operar con AeroDestino ✈️</small>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
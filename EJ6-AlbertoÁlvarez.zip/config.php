
<?php
$servername = "localhost";
$username = "aav";
$password = "aav";
$dbname = "bbdd_aav_mockaroo";
?>
<form action="data_insert_single.php" method="post">
    Firstname: <input type="text" name="firstname"><br>
    Lastname: <input type="text" name="lastname"><br>
    Email: <input type="email" name="email"><br>
    Código usuario: <input type="text" name="codigo_usuario"><br>
    <input type="submit" value="Insertar">
</form>

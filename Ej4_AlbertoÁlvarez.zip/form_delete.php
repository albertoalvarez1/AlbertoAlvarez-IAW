<form action="data_delete.php" method="post">
  ID del usuario a borrar: <input type="number" name="id"><br>
  <input type="submit" value="Borrar">
</form>

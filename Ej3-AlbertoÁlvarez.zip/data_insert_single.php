 <?php
include 'config.php';

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully<br>";

//Insert data in the table MyGuests
$sql = "INSERT INTO MyGuests (firstname, lastname, email, num_tlf, cod_usuario)
VALUES ('John', 'Doe', 'john@example.com', '+34 652192425', 'u56789')";

if (!mysqli_query($conn, $sql)) {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
else {
    echo "New record created successfully";
}

// Close connection
mysqli_close($conn);
?>


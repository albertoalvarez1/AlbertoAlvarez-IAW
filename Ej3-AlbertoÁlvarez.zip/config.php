 <?php
$servername = "localhost";
$username = "aav";
$password = "aav";
$dbname = "bd_w3_aav";
?>
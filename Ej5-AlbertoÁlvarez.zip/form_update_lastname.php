<?php
include "cabecera.html";
?>
<form action="data_update.php" method="post">
  ID del usuario: <input type="number" name="id"><br>
  Nuevo apellido: <input type="text" name="lastname"><br>
  <input type="submit" value="Actualizar">
</form>
